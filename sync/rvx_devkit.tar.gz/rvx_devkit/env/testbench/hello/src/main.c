#include "platform_info.h"
#include "ervp_printf.h"
#include "ervp_multicore_synch.h"

int main() {
	printf("Hello World!\n");
	return 0;
}
