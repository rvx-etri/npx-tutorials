// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2025-06-18
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"



module ERVP_ASYNCH_FIFO_ADVANCED
(
	wclk,
	wrstnn,
	wready,
  wfull,
  wstartindex,
  wlastindex,
	wrequest,
	wdata,
  wnum,

	rclk,
	rrstnn,
	rready,
	rempty,
  rstartindex,
  rlastindex,
	rrequest,
	rdata,
  rnum
);



parameter BW_DATA = 32;
parameter BW_PARTIAL_WRITE = 32;
parameter BW_PARTIAL_READ = 32;
parameter DEPTH = 4;
parameter BW_NUM_DATA = 32;

`include "ervp_log_util.vf"
`include "ervp_bitwidth_util.vf"

localparam  RVX_LPARA_00 = `DIVIDERU(BW_DATA, BW_PARTIAL_WRITE);
localparam  RVX_LPARA_06 = RVX_LPARA_00 * BW_PARTIAL_WRITE;
localparam  RVX_LPARA_07 = `DIVIDERU(BW_DATA, BW_PARTIAL_READ);
localparam  RVX_LPARA_08 = RVX_LPARA_07 * BW_PARTIAL_READ;

input wire wclk;
input wire wrstnn;
output wire wready;
output wire wfull;
output wire wstartindex;
output wire wlastindex;
input wire wrequest;
input wire [BW_PARTIAL_WRITE-1:0] wdata;
output wire [BW_NUM_DATA-1:0] wnum;

input wire rclk;
input wire rrstnn;
output wire rready;
output wire rempty;
output wire rstartindex;
output wire rlastindex;
input wire rrequest;
output wire [BW_PARTIAL_READ-1:0] rdata;
output wire [BW_NUM_DATA-1:0] rnum;

genvar i;

wire [RVX_LPARA_00-1:0] rvx_signal_11;
wire [RVX_LPARA_00-1:0] rvx_signal_18;
wire [RVX_LPARA_00-1:0] rvx_signal_35;

wire [RVX_LPARA_00-1:0] rvx_signal_12;
wire [RVX_LPARA_00-1:0] rvx_signal_43;
wire [RVX_LPARA_00-1:0] rvx_signal_29;

wire [BW_PARTIAL_WRITE-1:0] rvx_signal_32 [RVX_LPARA_00-1:0];
wire [BW_PARTIAL_WRITE-1:0] rvx_signal_10 [RVX_LPARA_00-1:0];
wire [RVX_LPARA_06-1:0] rvx_signal_04;
wire [RVX_LPARA_08-1:0] rvx_signal_08;

wire [RVX_LPARA_00-1:0] rvx_signal_15;
wire [RVX_LPARA_00-1:0] rvx_signal_05;
wire rvx_signal_41;

wire [RVX_LPARA_07-1:0] rvx_signal_14;
wire [RVX_LPARA_07-1:0] rvx_signal_24;
wire rvx_signal_00;

localparam  RVX_LPARA_09 = REQUIRED_BITWIDTH_SIGNED(DEPTH)+1;
localparam  RVX_LPARA_10 = 0;

wire rvx_signal_46;
wire rvx_signal_39;
wire [RVX_LPARA_09-1:0] rvx_signal_40;
wire [RVX_LPARA_09-1:0] rvx_signal_21;

localparam  RVX_LPARA_05 = 1;
localparam  RVX_LPARA_02 = DEPTH;

wire rvx_signal_34;
wire rvx_signal_26;
wire rvx_signal_38;
wire rvx_signal_03;
wire rvx_signal_01;
wire [RVX_LPARA_05-1:0] rvx_signal_45;

wire rvx_signal_13;
wire rvx_signal_22;
wire rvx_signal_36;
wire rvx_signal_25;
wire rvx_signal_28;
wire [RVX_LPARA_05-1:0] rvx_signal_27;

localparam  RVX_LPARA_03 = REQUIRED_BITWIDTH_SIGNED(DEPTH)+1;
localparam  RVX_LPARA_11 = DEPTH;

wire rvx_signal_02;
wire rvx_signal_31;
wire [RVX_LPARA_03-1:0] rvx_signal_47;
wire [RVX_LPARA_03-1:0] rvx_signal_37;

localparam  RVX_LPARA_01 = 1;
localparam  RVX_LPARA_04 = DEPTH;

wire rvx_signal_06;
wire rvx_signal_17;
wire rvx_signal_42;
wire rvx_signal_33;
wire rvx_signal_19;
wire [RVX_LPARA_01-1:0] rvx_signal_23;

wire rvx_signal_30;
wire rvx_signal_20;
wire rvx_signal_16;
wire rvx_signal_44;
wire rvx_signal_07;
wire [RVX_LPARA_01-1:0] rvx_signal_09;

generate
for(i=0; i<RVX_LPARA_00; i=i+1)
begin : i_generate_fifo
	ERVP_ASYNCH_FIFO
	#(
		.BW_DATA(BW_PARTIAL_WRITE),
		.DEPTH(DEPTH)
	)
	i_rvx_instance_6
	(
		.wclk(wclk),
		.wrstnn(wrstnn),
		.wready(rvx_signal_11[i]),		
		.wrequest(rvx_signal_18[i]),
		.wdata(rvx_signal_32[i]),
		.wfull(rvx_signal_35[i]),

		.rclk(rclk),
		.rrstnn(rrstnn),
		.rready(rvx_signal_12[i]),
		.rrequest(rvx_signal_43[i]),
		.rdata(rvx_signal_10[i]),
		.rempty(rvx_signal_29[i])
	);
	assign rvx_signal_32[i] = wdata;
	assign rvx_signal_04[(i+1)*BW_PARTIAL_WRITE-1-:BW_PARTIAL_WRITE] = rvx_signal_10[i];
end
endgenerate
assign rvx_signal_08 = $unsigned(rvx_signal_04);

ERVP_COUNTER_WITH_ONEHOT_ENCODING
#(
	.COUNT_LENGTH(RVX_LPARA_00),
	.CIRCULAR(1)
)
i_rvx_instance_5
(
	.clk(wclk),
	.rstnn(wrstnn),
	.enable(1'b 1),
	.init(1'b 0),
	.count(rvx_signal_41),
	.value(rvx_signal_15),
	.is_first_count(wstartindex),
	.is_last_count(wlastindex)
);

assign rvx_signal_05 = (RVX_LPARA_00==1)? 1 : rvx_signal_15;
assign wready = ((rvx_signal_05 & rvx_signal_11)!=0);
assign wfull = ((rvx_signal_05 & rvx_signal_35)!=0);
assign rvx_signal_18 = wrequest? rvx_signal_05 : 0;
assign rvx_signal_41 = wready & wrequest;

ERVP_COUNTER_WITH_ONEHOT_ENCODING
#(
	.COUNT_LENGTH(RVX_LPARA_07),
	.CIRCULAR(1)
)
i_rvx_instance_3
(
	.clk(rclk),
	.rstnn(rrstnn),
	.enable(1'b 1),
	.init(1'b 0),
	.count(rvx_signal_00),
	.value(rvx_signal_14),
	.is_first_count(rstartindex),
	.is_last_count(rlastindex)
);

assign rvx_signal_24 = (RVX_LPARA_07==1)? 1 : rvx_signal_14;
assign rready = `IS_ALL_ONE(rvx_signal_12);
assign rempty = (rvx_signal_29!=0);
assign rvx_signal_43 = (rvx_signal_00 & rvx_signal_24[RVX_LPARA_07-1])? `ALL_ONE : 0;

ERVP_MUX_WITH_ONEHOT_ENCODED_SELECT
#(
  .BW_DATA(BW_PARTIAL_READ),
  .NUM_DATA(RVX_LPARA_07),
  .ACTIVE_HIGH(1)
)
i_rvx_instance_0
(
	.data_input_list(rvx_signal_08),
	.select(rvx_signal_24),
	.data_output(rdata)
);

assign rvx_signal_00 = rready & rrequest;

ERVP_UPDOWN_COUNTER
#(
  .BW_COUNTER(RVX_LPARA_09),
  .RESET_NUMBER(RVX_LPARA_10),
  .UNSIGNED(0)
)
i_rvx_instance_2
(
	.clk(rclk),
  .rstnn(rrstnn),
	.enable(1'b 1),
	.init(1'b 0),
	.up(rvx_signal_46),
	.down(rvx_signal_39),
	.count_amount(rvx_signal_40),
	.value(rvx_signal_21),
	.is_upper_limit(),
	.is_lower_limit()
);

assign rvx_signal_46 = rvx_signal_36;
assign rvx_signal_39 = rstartindex & rvx_signal_00;
assign rvx_signal_40 = 1;
assign rnum = rvx_signal_21;

ERVP_ASYNCH_FIFO
#(
  .BW_DATA(RVX_LPARA_05),
  .DEPTH(RVX_LPARA_02)
)
i_rvx_instance_7
(
  .wclk(rvx_signal_34),
  .wrstnn(rvx_signal_26),
  .wready(rvx_signal_38),
  .wfull(rvx_signal_03),
  .wrequest(rvx_signal_01),
  .wdata(rvx_signal_45),  

  .rclk(rvx_signal_13),
  .rrstnn(rvx_signal_22),
  .rready(rvx_signal_36),
  .rempty(rvx_signal_25),
  .rrequest(rvx_signal_28),
  .rdata(rvx_signal_27)
);

assign rvx_signal_34 = wclk;
assign rvx_signal_26 = wrstnn;
assign rvx_signal_01 = wstartindex & rvx_signal_41;
assign rvx_signal_45 = 0;

assign rvx_signal_13 = rclk;
assign rvx_signal_22 = rrstnn;
assign rvx_signal_28 = rvx_signal_46;

ERVP_UPDOWN_COUNTER
#(
  .BW_COUNTER(RVX_LPARA_03),
  .RESET_NUMBER(RVX_LPARA_11),
  .UNSIGNED(0)
)
i_rvx_instance_4
(
	.clk(wclk),
  .rstnn(wrstnn),
	.enable(1'b 1),
	.init(1'b 0),
	.up(rvx_signal_02),
	.down(rvx_signal_31),
	.count_amount(rvx_signal_47),
	.value(rvx_signal_37),
	.is_upper_limit(),
	.is_lower_limit()
);

assign rvx_signal_02 = rvx_signal_16; 
assign rvx_signal_31 = wstartindex & rvx_signal_41;
assign rvx_signal_47 = 1;
assign wnum = rvx_signal_37;

ERVP_ASYNCH_FIFO
#(
  .BW_DATA(RVX_LPARA_01),
  .DEPTH(RVX_LPARA_04)
)
i_rvx_instance_1
(
  .wclk(rvx_signal_06),
  .wrstnn(rvx_signal_17),
  .wready(rvx_signal_42),
  .wfull(rvx_signal_33),
  .wrequest(rvx_signal_19),
  .wdata(rvx_signal_23),  

  .rclk(rvx_signal_30),
  .rrstnn(rvx_signal_20),
  .rready(rvx_signal_16),
  .rempty(rvx_signal_44),
  .rrequest(rvx_signal_07),
  .rdata(rvx_signal_09)
);

assign rvx_signal_06 = rclk;
assign rvx_signal_17 = rrstnn;
assign rvx_signal_19 = rstartindex & rvx_signal_00;
assign rvx_signal_23 = 0;

assign rvx_signal_30 = wclk;
assign rvx_signal_20 = wrstnn;
assign rvx_signal_07 = rvx_signal_02;

endmodule
