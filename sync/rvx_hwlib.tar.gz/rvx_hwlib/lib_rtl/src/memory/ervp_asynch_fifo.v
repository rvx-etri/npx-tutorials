// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2025-06-18
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"



module ERVP_ASYNCH_FIFO
(
	wclk,
	wrstnn,
	wready,
	wrequest,
	wfull,
	wdata,
	rclk,
	rrstnn,
	rready,
	rrequest,
	rempty,
	rdata
);



parameter BW_DATA = 1;
parameter DEPTH = 1;
parameter WRITE_READY_SIZE = 1;
parameter NO_DATA = 0;

`include "ervp_log_util.vf"
`include "ervp_bitwidth_util.vf"

localparam  RVX_LPARA_0 = REQUIRED_BITWIDTH_INDEX(DEPTH);
localparam  RVX_LPARA_1 = 1<<RVX_LPARA_0;

input wire wclk, wrstnn;
output wire [WRITE_READY_SIZE-1:0] wready;
input wire wrequest;
output reg wfull;
input wire [BW_DATA-1:0] wdata;

input wire rclk, rrstnn;
output wire rready;
output reg rempty;
input wire rrequest;
output wire [BW_DATA-1:0] rdata;

integer j;

reg [BW_DATA-1:0] rvx_signal_07 [0:RVX_LPARA_1-1];

wire [RVX_LPARA_0-1:0] rvx_signal_09, rvx_signal_12;
reg [RVX_LPARA_0:0] rvx_signal_14, rvx_signal_02;
reg [RVX_LPARA_0:0] rvx_signal_17, rvx_signal_16;

wire [RVX_LPARA_0:0] rvx_signal_06;
wire [RVX_LPARA_0:0] rvx_signal_11;

wire [RVX_LPARA_0:0] rvx_signal_13, rvx_signal_10;
wire [RVX_LPARA_0:0] rvx_signal_08, rvx_signal_00;
reg [RVX_LPARA_0:0] rvx_signal_15;

wire [RVX_LPARA_0:0] rvx_signal_04, rvx_signal_05;
reg [`MAX(WRITE_READY_SIZE,2)-1:0] rvx_signal_03;
reg rvx_signal_01;

assign rdata = (NO_DATA==1)? 0 : rvx_signal_07 [rvx_signal_12];

always @(posedge wclk, negedge wrstnn)
begin
	if(wrstnn==0)
		for (j=0; j<RVX_LPARA_1; j=j+1)
			rvx_signal_07[j] <= 0;
	else if (wrequest && !wfull)
		rvx_signal_07[rvx_signal_09] <= wdata;
end
	
ERVP_SYNCHRONIZER
#(
	.BW_DATA(RVX_LPARA_0+1)
)
i_rvx_instance_0
(
	.clk(wclk),
	.rstnn(wrstnn),
	.enable(1'b 1),
	.asynch_value(rvx_signal_17),
	.synch_value(rvx_signal_06)
);

ERVP_SYNCHRONIZER
#(
	.BW_DATA(RVX_LPARA_0+1)
)
i_rvx_instance_1
(
	.clk(rclk),
	.rstnn(rrstnn),
	.enable(1'b 1),
	.asynch_value(rvx_signal_14),
	.synch_value(rvx_signal_11)
);

always @(posedge rclk or negedge rrstnn)
begin
	if (!rrstnn)
		{rvx_signal_16, rvx_signal_17} <= 0;
	else
		{rvx_signal_16, rvx_signal_17} <= {rvx_signal_10, rvx_signal_13};
end

assign rvx_signal_12 = rvx_signal_16[RVX_LPARA_0-1:0];
assign rvx_signal_10 = rvx_signal_16 + (rrequest & ~rempty);
assign rvx_signal_13 = `BINARY2GRAY(rvx_signal_10);

always @(posedge rclk or negedge rrstnn)
begin
	if (!rrstnn)
		rempty <= 1'b1;
	else
		rempty <= (rvx_signal_13 == rvx_signal_11);
end

assign rready = ~rempty;

always @(posedge wclk or negedge wrstnn)
begin
	if (!wrstnn)
		{rvx_signal_02, rvx_signal_14} <= 0;
	else
		{rvx_signal_02, rvx_signal_14} <= {rvx_signal_00, rvx_signal_08};
end

assign rvx_signal_09 = rvx_signal_02[RVX_LPARA_0-1:0];
assign rvx_signal_00 = rvx_signal_02 + (wrequest & ~wfull);
assign rvx_signal_08 = `BINARY2GRAY(rvx_signal_00);

always@(*)
begin
	rvx_signal_15 = rvx_signal_06;
	rvx_signal_15[RVX_LPARA_0:RVX_LPARA_0-1] = ~rvx_signal_06[RVX_LPARA_0:RVX_LPARA_0-1];
end

always @(posedge wclk or negedge wrstnn)
begin
	if (!wrstnn)
		wfull <= 1'b0;
	else
		wfull <= (rvx_signal_08==rvx_signal_15);
end

always@(*)
begin
	rvx_signal_03 = 0;
	rvx_signal_03[0] = ~wfull;
	rvx_signal_03[1] = (~wfull) & (~rvx_signal_01);
end

assign wready = $unsigned(rvx_signal_03);

assign rvx_signal_05 = rvx_signal_02 + 1'b 1 + (wrequest & ~wfull);
assign rvx_signal_04 = `BINARY2GRAY(rvx_signal_05);

always @(posedge wclk or negedge wrstnn)
begin
	if (!wrstnn)
		rvx_signal_01 <= (RVX_LPARA_1==1)? 1'b1 : 1'b0;
	else
		rvx_signal_01 <= (rvx_signal_04==rvx_signal_15);
end

endmodule

