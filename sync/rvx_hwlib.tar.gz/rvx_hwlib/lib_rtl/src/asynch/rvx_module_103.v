// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2025-06-18
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"
`include "rvx_include_15.vh"





module RVX_MODULE_103
(
	rvx_port_03,
	rvx_port_06,
	rvx_port_08,
	rvx_port_07,
	rvx_port_01,
	rvx_port_05,

	rvx_port_09,
	rvx_port_02,
	rvx_port_04,
	rvx_port_00
);





parameter RVX_GPARA_5 = -1;
parameter RVX_GPARA_0 = 4;
localparam  RVX_LPARA_0 = `RVX_GDEF_020 + RVX_GPARA_0;
parameter RVX_GPARA_3 = RVX_LPARA_0+1;

parameter RVX_GPARA_2 = 4;
parameter RVX_GPARA_4 = RVX_GPARA_0 - RVX_GPARA_2;
parameter RVX_GPARA_1 = RVX_GPARA_0;

input wire rvx_port_03, rvx_port_06;

input wire [RVX_GPARA_3-1:0] rvx_port_08;
output wire rvx_port_07;
output wire [RVX_GPARA_3-1:0] rvx_port_01;
input wire rvx_port_05;

output wire rvx_port_09;
output wire [RVX_GPARA_4-1:0] rvx_port_02;
input wire rvx_port_04;
input wire [RVX_GPARA_1-1:0] rvx_port_00;

wire rvx_signal_13;
wire rvx_signal_00;
wire [RVX_LPARA_0-1:0] rvx_signal_15;
wire rvx_signal_10;

wire rvx_signal_12;
wire [RVX_LPARA_0-1:0] rvx_signal_08;
wire rvx_signal_02;

wire [`RVX_GDEF_020-1:0] rvx_signal_01;
wire [RVX_GPARA_0-1:0] rvx_signal_07;
wire [RVX_GPARA_2-1:0] rvx_signal_05;

reg [`RVX_GDEF_020-1:0] rvx_signal_04;
reg [RVX_GPARA_0-1:0] rvx_signal_11;

`define RVX_LDEF_4 2
`define RVX_LDEF_1 0
`define RVX_LDEF_2 1
`define RVX_LDEF_3 2
`define RVX_LDEF_0 3

reg [`RVX_LDEF_4-1:0] rvx_signal_03;
wire rvx_signal_14;
wire rvx_signal_09;
wire rvx_signal_16;
wire rvx_signal_06;

RVX_MODULE_024
#(
	.RVX_GPARA_0(RVX_LPARA_0),
	.RVX_GPARA_1(RVX_GPARA_3)
)
i_rvx_instance_0
(
	.rvx_port_5(rvx_port_03),
	.rvx_port_0(rvx_port_06),
	.rvx_port_6(rvx_signal_13),
	.rvx_port_4(rvx_signal_15),
	.rvx_port_3(rvx_signal_10),
	.rvx_port_1(rvx_port_08),
	.rvx_port_2(rvx_port_07)
);

RVX_MODULE_050
#(
	.RVX_GPARA_1(RVX_LPARA_0),
	.RVX_GPARA_0(RVX_GPARA_3)
)
i_rvx_instance_1
(
	.rvx_port_4(rvx_port_03),
	.rvx_port_0(rvx_port_06),
	.rvx_port_1(rvx_signal_12),
	.rvx_port_5(rvx_signal_08),
	.rvx_port_6(rvx_signal_02),
	.rvx_port_3(rvx_port_01),
	.rvx_port_2(rvx_port_05)
);

assign {rvx_signal_01,rvx_signal_07} = rvx_signal_15;
assign {rvx_signal_05,rvx_port_02} = $unsigned(rvx_signal_07);

always@(posedge rvx_port_03, negedge rvx_port_06)
begin
	if(rvx_port_06==0)
		rvx_signal_03 <= `RVX_LDEF_1;
	else
		case(rvx_signal_03)
			`RVX_LDEF_1:
				if(rvx_signal_14)
					rvx_signal_03 <= `RVX_LDEF_2;
				else if(rvx_signal_09)
					rvx_signal_03 <= `RVX_LDEF_0;
			`RVX_LDEF_2:
				rvx_signal_03 <= `RVX_LDEF_3;
			`RVX_LDEF_3:
				if(rvx_signal_16)
					rvx_signal_03 <= `RVX_LDEF_0;
			`RVX_LDEF_0:
				if(rvx_signal_06)
					rvx_signal_03 <= `RVX_LDEF_1;
		endcase
end

assign rvx_signal_10 = (rvx_signal_03==`RVX_LDEF_1);
assign rvx_signal_00 = rvx_signal_13 & rvx_signal_10; 
assign rvx_signal_14 = rvx_signal_00 & (rvx_signal_01==`RVX_GDEF_316) & ($unsigned(rvx_signal_05)==RVX_GPARA_5);
assign rvx_signal_16 = (rvx_signal_03==`RVX_LDEF_3) & rvx_port_04;
assign rvx_signal_09 = rvx_signal_00 & (~rvx_signal_14);

assign rvx_port_09 = (rvx_signal_03==`RVX_LDEF_2) | (rvx_signal_03==`RVX_LDEF_3);

always@(posedge rvx_port_03, negedge rvx_port_06)
begin
	if(rvx_port_06==0)
		 {rvx_signal_04,rvx_signal_11} <= 0;
	else if(rvx_signal_09)
		 {rvx_signal_04,rvx_signal_11} <= {rvx_signal_01,rvx_signal_07};
	else if(rvx_signal_16)
	begin
		rvx_signal_04 <= `RVX_GDEF_171;
		rvx_signal_11 <= $unsigned(rvx_port_00);
	end
end

assign rvx_signal_08 = {rvx_signal_04,rvx_signal_11};

assign rvx_signal_12 = (rvx_signal_03==`RVX_LDEF_0);
assign rvx_signal_06 = (rvx_signal_03==`RVX_LDEF_0) & rvx_signal_02;

`undef RVX_LDEF_3
`undef RVX_LDEF_1
`undef RVX_LDEF_0
`undef RVX_LDEF_4
`undef RVX_LDEF_2
endmodule

