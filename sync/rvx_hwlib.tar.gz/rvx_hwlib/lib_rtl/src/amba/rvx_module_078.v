// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2025-06-18
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"
`include "ervp_axi_define.vh"





module RVX_MODULE_078
(
  rvx_port_49,
  rvx_port_31,
  rvx_port_29,
  rvx_port_02,
  rvx_port_52,

  rvx_port_18,
  rvx_port_26,
  rvx_port_38,
  rvx_port_24,
  rvx_port_50,
  rvx_port_35,
  rvx_port_43,
  rvx_port_37,
  rvx_port_54,
  rvx_port_07,
  rvx_port_33,
  rvx_port_64,
  rvx_port_25,
  rvx_port_60,
  rvx_port_40,
  rvx_port_48,
  rvx_port_08,
  rvx_port_57,
  rvx_port_04,
  rvx_port_46,
  rvx_port_19,
  rvx_port_36,
  rvx_port_05,
  rvx_port_41,
  rvx_port_11,
  rvx_port_13,
  rvx_port_17,
  rvx_port_47,
  rvx_port_45,
  rvx_port_53,

  rvx_port_61,
  rvx_port_06,
  rvx_port_56,
  rvx_port_14,
  rvx_port_12,
  rvx_port_23,
  rvx_port_63,
  rvx_port_09,
  rvx_port_28,
  rvx_port_32,
  rvx_port_03,
  rvx_port_34,
  rvx_port_42,
  rvx_port_16,
  rvx_port_55,
  rvx_port_39,
  rvx_port_27,
  rvx_port_20,
  rvx_port_62,
  rvx_port_10,
  rvx_port_44,
  rvx_port_30,
  rvx_port_15,
  rvx_port_01,
  rvx_port_00,
  rvx_port_51,
  rvx_port_22,
  rvx_port_59,
  rvx_port_58,
  rvx_port_21
);





parameter RVX_GPARA_1 = 32;
parameter RVX_GPARA_3 = 32;
parameter RVX_GPARA_2 = 4;
parameter RVX_GPARA_0 = 1;

input wire rvx_port_49;
input wire rvx_port_31;
input wire rvx_port_29;
input wire rvx_port_02;
output wire rvx_port_52;

input wire [RVX_GPARA_0-1:0] rvx_port_18;
output wire [RVX_GPARA_0-1:0] rvx_port_26;
output wire [RVX_GPARA_0-1:0] rvx_port_38;
output wire [`BW_AXI_RRESP*RVX_GPARA_0-1:0] rvx_port_24;
output wire [RVX_GPARA_3*RVX_GPARA_0-1:0] rvx_port_50;
output wire [RVX_GPARA_2*RVX_GPARA_0-1:0] rvx_port_35;
output wire [RVX_GPARA_0-1:0] rvx_port_43;
input wire [RVX_GPARA_0-1:0] rvx_port_37;
input wire [`BW_AXI_ABURST*RVX_GPARA_0-1:0] rvx_port_54;
input wire [`BW_AXI_ASIZE*RVX_GPARA_0-1:0] rvx_port_07;
input wire [`BW_AXI_ALEN*RVX_GPARA_0-1:0] rvx_port_33;
input wire [RVX_GPARA_1*RVX_GPARA_0-1:0] rvx_port_64;
input wire [RVX_GPARA_2*RVX_GPARA_0-1:0] rvx_port_25;
input wire [RVX_GPARA_0-1:0] rvx_port_60;
output wire [RVX_GPARA_0-1:0] rvx_port_40;
output wire [`BW_AXI_BRESP*RVX_GPARA_0-1:0] rvx_port_48;
output wire [RVX_GPARA_2*RVX_GPARA_0-1:0] rvx_port_08;
output wire [RVX_GPARA_0-1:0] rvx_port_57;
input wire [RVX_GPARA_0-1:0] rvx_port_04;
input wire [RVX_GPARA_0-1:0] rvx_port_46;
input wire [`BW_AXI_WSTRB(RVX_GPARA_3)*RVX_GPARA_0-1:0] rvx_port_19;
input wire [RVX_GPARA_3*RVX_GPARA_0-1:0] rvx_port_36;
input wire [RVX_GPARA_2*RVX_GPARA_0-1:0] rvx_port_05;
output wire [RVX_GPARA_0-1:0] rvx_port_41;
input wire [RVX_GPARA_0-1:0] rvx_port_11;
input wire [`BW_AXI_ABURST*RVX_GPARA_0-1:0] rvx_port_13;
input wire [`BW_AXI_ASIZE*RVX_GPARA_0-1:0] rvx_port_17;
input wire [`BW_AXI_ALEN*RVX_GPARA_0-1:0] rvx_port_47;
input wire [RVX_GPARA_1*RVX_GPARA_0-1:0] rvx_port_45;
input wire [RVX_GPARA_2*RVX_GPARA_0-1:0] rvx_port_53;

output wire rvx_port_61;
input wire rvx_port_06;
input wire rvx_port_56;
input wire [`BW_AXI_RRESP-1:0] rvx_port_14;
input wire [RVX_GPARA_3-1:0] rvx_port_12;
input wire [RVX_GPARA_2-1:0] rvx_port_23;
input wire rvx_port_63;
output wire rvx_port_09;
output wire [`BW_AXI_ABURST-1:0] rvx_port_28;
output wire [`BW_AXI_ASIZE-1:0] rvx_port_32;
output wire [`BW_AXI_ALEN-1:0] rvx_port_03;
output wire [RVX_GPARA_1-1:0] rvx_port_34;
output wire [RVX_GPARA_2-1:0] rvx_port_42;
output wire rvx_port_16;
input wire rvx_port_55;
input wire [`BW_AXI_BRESP-1:0] rvx_port_39;
input wire [RVX_GPARA_2-1:0] rvx_port_27;
input wire rvx_port_20;
output wire rvx_port_62;
output wire rvx_port_10;
output wire [`BW_AXI_WSTRB(RVX_GPARA_3)-1:0] rvx_port_44;
output wire [RVX_GPARA_3-1:0] rvx_port_30;
output wire [RVX_GPARA_2-1:0] rvx_port_15;
input wire rvx_port_01;
output wire rvx_port_00;
output wire [`BW_AXI_ABURST-1:0] rvx_port_51;
output wire [`BW_AXI_ASIZE-1:0] rvx_port_22;
output wire [`BW_AXI_ALEN-1:0] rvx_port_59;
output wire [RVX_GPARA_1-1:0] rvx_port_58;
output wire [RVX_GPARA_2-1:0] rvx_port_21;

genvar i;

wire [`BW_AXI_RRESP-1:0] rvx_signal_07 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_3-1:0] rvx_signal_39 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_2-1:0] rvx_signal_53 [RVX_GPARA_0-1:0];
wire [`BW_AXI_ABURST-1:0] rvx_signal_86 [RVX_GPARA_0-1:0];
wire [`BW_AXI_ASIZE-1:0] rvx_signal_67 [RVX_GPARA_0-1:0];
wire [`BW_AXI_ALEN-1:0] rvx_signal_02 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_1-1:0] rvx_signal_25 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_2-1:0] rvx_signal_12 [RVX_GPARA_0-1:0];
wire [`BW_AXI_BRESP-1:0] rvx_signal_77 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_2-1:0] rvx_signal_41 [RVX_GPARA_0-1:0];
wire [`BW_AXI_WSTRB(RVX_GPARA_3)-1:0] rvx_signal_03 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_3-1:0] rvx_signal_74 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_2-1:0] rvx_signal_31 [RVX_GPARA_0-1:0];
wire [`BW_AXI_ABURST-1:0] rvx_signal_71 [RVX_GPARA_0-1:0];
wire [`BW_AXI_ASIZE-1:0] rvx_signal_62 [RVX_GPARA_0-1:0];
wire [`BW_AXI_ALEN-1:0] rvx_signal_42 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_1-1:0] rvx_signal_06 [RVX_GPARA_0-1:0];
wire [RVX_GPARA_2-1:0] rvx_signal_73 [RVX_GPARA_0-1:0];

localparam  RVX_LPARA_1 = `BW_ARCHANNEL(RVX_GPARA_2,RVX_GPARA_1) - RVX_GPARA_2;

wire [RVX_GPARA_0-1:0] rvx_signal_17;
wire [RVX_GPARA_0-1:0] rvx_signal_89;
wire [RVX_GPARA_0*RVX_LPARA_1-1:0] rvx_signal_83;
wire [RVX_GPARA_0-1:0] rvx_signal_47;
wire rvx_signal_40;
wire rvx_signal_37;
wire [RVX_LPARA_1-1:0] rvx_signal_45;
wire [RVX_LPARA_1-1:0] rvx_signal_04 [RVX_GPARA_0-1:0];

localparam  RVX_LPARA_2 = `BW_AWCHANNEL(RVX_GPARA_2,RVX_GPARA_1) - RVX_GPARA_2;

wire [RVX_GPARA_0-1:0] rvx_signal_50;
wire [RVX_GPARA_0-1:0] rvx_signal_36;
wire [RVX_GPARA_0*RVX_LPARA_2-1:0] rvx_signal_09;
wire [RVX_GPARA_0-1:0] rvx_signal_18;
wire rvx_signal_63;
wire rvx_signal_00;
wire [RVX_LPARA_2-1:0] rvx_signal_13;
wire [RVX_LPARA_2-1:0] rvx_signal_34 [RVX_GPARA_0-1:0];

localparam  RVX_LPARA_3 = `BW_WCHANNEL(RVX_GPARA_2,RVX_GPARA_3) - RVX_GPARA_2;

wire [RVX_GPARA_0-1:0] rvx_signal_72;
wire [RVX_GPARA_0-1:0] rvx_signal_59;
wire [RVX_GPARA_0*RVX_LPARA_3-1:0] rvx_signal_82;
wire [RVX_GPARA_0-1:0] rvx_signal_56;
wire rvx_signal_87;
wire rvx_signal_24;
wire [RVX_LPARA_3-1:0] rvx_signal_43;
wire [RVX_LPARA_3-1:0] rvx_signal_90 [RVX_GPARA_0-1:0];

localparam  RVX_LPARA_4 = `BW_RCHANNEL(RVX_GPARA_2,RVX_GPARA_3) - RVX_GPARA_2;

wire rvx_signal_38;
wire rvx_signal_16;
wire [RVX_LPARA_4-1:0] rvx_signal_10;
wire [RVX_GPARA_0-1:0] rvx_signal_65;
wire [RVX_GPARA_0-1:0] rvx_signal_91;
wire [RVX_GPARA_0-1:0] rvx_signal_58;
wire [RVX_GPARA_0*RVX_LPARA_4-1:0] rvx_signal_52;
wire [RVX_LPARA_4-1:0] rvx_signal_26 [RVX_GPARA_0-1:0];

localparam  RVX_LPARA_0 = `BW_BCHANNEL(RVX_GPARA_2) - RVX_GPARA_2;

wire rvx_signal_33;
wire rvx_signal_66;
wire [RVX_LPARA_0-1:0] rvx_signal_85;
wire [RVX_GPARA_0-1:0] rvx_signal_22;
wire [RVX_GPARA_0-1:0] rvx_signal_54;
wire [RVX_GPARA_0-1:0] rvx_signal_20;
wire [RVX_GPARA_0*RVX_LPARA_0-1:0] rvx_signal_70;
wire [RVX_LPARA_0-1:0] rvx_signal_69 [RVX_GPARA_0-1:0];

wire [RVX_GPARA_0-1:0] rvx_signal_29;
wire [RVX_GPARA_0-1:0] rvx_signal_64;
wire [RVX_GPARA_0-1:0] rvx_signal_27;
wire rvx_signal_23;
wire [RVX_GPARA_0-1:0] rvx_signal_60;
wire rvx_signal_14;

wire rvx_signal_11;
wire rvx_signal_08;
wire rvx_signal_48;
wire [RVX_GPARA_0-1:0] rvx_signal_79;
wire rvx_signal_32;
wire [RVX_GPARA_0-1:0] rvx_signal_88;

wire [RVX_GPARA_0-1:0] rvx_signal_15;
wire [RVX_GPARA_0-1:0] rvx_signal_76;
wire [RVX_GPARA_0-1:0] rvx_signal_81;
wire rvx_signal_05;
wire [RVX_GPARA_0-1:0] rvx_signal_01;
wire rvx_signal_46;

wire rvx_signal_21;
wire rvx_signal_19;
wire rvx_signal_28;
wire [RVX_GPARA_0-1:0] rvx_signal_75;
wire rvx_signal_84;
wire rvx_signal_35;
wire rvx_signal_30;
wire [RVX_GPARA_0-1:0] rvx_signal_55;

wire rvx_signal_78;
wire rvx_signal_51;
wire rvx_signal_80;
wire rvx_signal_49;
wire rvx_signal_57;
wire [RVX_GPARA_0-1:0] rvx_signal_68;
wire [RVX_GPARA_0-1:0] rvx_signal_92;
wire rvx_signal_61;
wire [RVX_GPARA_0-1:0] rvx_signal_44;

generate
for(i=0; i<RVX_GPARA_0; i=i+1)
begin : i_gen_axi_element
  assign rvx_port_24[(i+1)*`BW_AXI_RRESP-1-:`BW_AXI_RRESP] = rvx_signal_07[i];
  assign rvx_port_50[(i+1)*RVX_GPARA_3-1-:RVX_GPARA_3] = rvx_signal_39[i];
  assign rvx_port_35[(i+1)*RVX_GPARA_2-1-:RVX_GPARA_2] = rvx_signal_53[i];
  assign rvx_signal_86[i] = rvx_port_54[(i+1)*`BW_AXI_ABURST-1-:`BW_AXI_ABURST];
  assign rvx_signal_67[i] = rvx_port_07[(i+1)*`BW_AXI_ASIZE-1-:`BW_AXI_ASIZE];
  assign rvx_signal_02[i] = rvx_port_33[(i+1)*`BW_AXI_ALEN-1-:`BW_AXI_ALEN];
  assign rvx_signal_25[i] = rvx_port_64[(i+1)*RVX_GPARA_1-1-:RVX_GPARA_1];
  assign rvx_signal_12[i] = rvx_port_25[(i+1)*RVX_GPARA_2-1-:RVX_GPARA_2];
  assign rvx_port_48[(i+1)*`BW_AXI_BRESP-1-:`BW_AXI_BRESP] = rvx_signal_77[i];
  assign rvx_port_08[(i+1)*RVX_GPARA_2-1-:RVX_GPARA_2] = rvx_signal_41[i];
  assign rvx_signal_03[i] = rvx_port_19[(i+1)*`BW_AXI_WSTRB(RVX_GPARA_3)-1-:`BW_AXI_WSTRB(RVX_GPARA_3)];
  assign rvx_signal_74[i] = rvx_port_36[(i+1)*RVX_GPARA_3-1-:RVX_GPARA_3];
  assign rvx_signal_31[i] = rvx_port_05[(i+1)*RVX_GPARA_2-1-:RVX_GPARA_2];
  assign rvx_signal_71[i] = rvx_port_13[(i+1)*`BW_AXI_ABURST-1-:`BW_AXI_ABURST];
  assign rvx_signal_62[i] = rvx_port_17[(i+1)*`BW_AXI_ASIZE-1-:`BW_AXI_ASIZE];
  assign rvx_signal_42[i] = rvx_port_47[(i+1)*`BW_AXI_ALEN-1-:`BW_AXI_ALEN];
  assign rvx_signal_06[i] = rvx_port_45[(i+1)*RVX_GPARA_1-1-:RVX_GPARA_1];
  assign rvx_signal_73[i] = rvx_port_53[(i+1)*RVX_GPARA_2-1-:RVX_GPARA_2];
end
endgenerate

RVX_MODULE_049
#(
  .RVX_GPARA_0(RVX_GPARA_0),
  .RVX_GPARA_1(RVX_LPARA_1)
)
i_rvx_instance_5
(
  .rvx_port_4(rvx_signal_17),
  .rvx_port_3(rvx_signal_89),
  .rvx_port_6(rvx_signal_83),
  .rvx_port_5(rvx_signal_47),
  .rvx_port_0(rvx_signal_40),
  .rvx_port_1(rvx_signal_37),
  .rvx_port_2(rvx_signal_45)
);

assign rvx_signal_17 = rvx_port_37;
assign rvx_port_43 = rvx_signal_89;
assign rvx_port_09 = rvx_signal_40;
assign rvx_signal_37 = rvx_port_63;
assign {rvx_port_34, rvx_port_03, rvx_port_32, rvx_port_28} = rvx_signal_45;
assign rvx_port_42 = rvx_signal_47;

generate
for(i=0; i<RVX_GPARA_0; i=i+1)
begin : i_gen_port_i_merge_ar
  assign rvx_signal_83[(i+1)*RVX_LPARA_1-1-:RVX_LPARA_1] = rvx_signal_04[i];
  assign rvx_signal_04[i] = {rvx_signal_25[i],rvx_signal_02[i],rvx_signal_67[i],rvx_signal_86[i]};
end
endgenerate

assign rvx_signal_47 = rvx_signal_79;

RVX_MODULE_049
#(
  .RVX_GPARA_0(RVX_GPARA_0),
  .RVX_GPARA_1(RVX_LPARA_2)
)
i_rvx_instance_7
(
  .rvx_port_4(rvx_signal_50),
  .rvx_port_3(rvx_signal_36),
  .rvx_port_6(rvx_signal_09),
  .rvx_port_5(rvx_signal_18),
  .rvx_port_0(rvx_signal_63),
  .rvx_port_1(rvx_signal_00),
  .rvx_port_2(rvx_signal_13)
);

assign rvx_signal_50 = rvx_port_11;
assign rvx_port_41 = rvx_signal_36;
assign rvx_port_00 = rvx_signal_63;
assign rvx_signal_00 = rvx_port_01;
assign {rvx_port_58, rvx_port_59, rvx_port_22, rvx_port_51} = rvx_signal_13;
assign rvx_port_21 = rvx_signal_18;

generate
for(i=0; i<RVX_GPARA_0; i=i+1)
begin : i_gen_port_i_merge_aw
  assign rvx_signal_09[(i+1)*RVX_LPARA_2-1-:RVX_LPARA_2] = rvx_signal_34[i];
  assign rvx_signal_34[i] = {rvx_signal_06[i],rvx_signal_42[i],rvx_signal_62[i],rvx_signal_71[i]};
end
endgenerate

assign rvx_signal_18 = rvx_signal_68;

RVX_MODULE_049
#(
  .RVX_GPARA_0(RVX_GPARA_0),
  .RVX_GPARA_1(RVX_LPARA_3)
)
i_rvx_instance_4
(
  .rvx_port_4(rvx_signal_72),
  .rvx_port_3(rvx_signal_59),
  .rvx_port_6(rvx_signal_82),
  .rvx_port_5(rvx_signal_56),
  .rvx_port_0(rvx_signal_87),
  .rvx_port_1(rvx_signal_24),
  .rvx_port_2(rvx_signal_43)
);

assign rvx_signal_72 = rvx_port_04;
assign rvx_port_57 = rvx_signal_59;
assign rvx_port_62 = rvx_signal_87;
assign rvx_signal_24 = rvx_port_20;
assign {rvx_port_30, rvx_port_44, rvx_port_10} = rvx_signal_43;
assign rvx_port_15 = rvx_signal_56;

generate
for(i=0; i<RVX_GPARA_0; i=i+1)
begin : i_gen_port_i_merge_w
  assign rvx_signal_82[(i+1)*RVX_LPARA_3-1-:RVX_LPARA_3] = rvx_signal_90[i];
  assign rvx_signal_90[i] = {rvx_signal_74[i],rvx_signal_03[i],rvx_port_46[i]};
end
endgenerate

assign rvx_signal_56 = rvx_signal_92;

RVX_MODULE_122
#(
  .RVX_GPARA_0(RVX_GPARA_0),
  .RVX_GPARA_1(RVX_LPARA_4)
)
i_rvx_instance_2
(
  .rvx_port_2(rvx_signal_38),
  .rvx_port_6(rvx_signal_16),
  .rvx_port_4(rvx_signal_10),
  .rvx_port_0(rvx_signal_65),
  .rvx_port_3(rvx_signal_91),
  .rvx_port_5(rvx_signal_58),
  .rvx_port_1(rvx_signal_52)
);

assign rvx_signal_38 = rvx_port_06;
assign rvx_port_61 = rvx_signal_16;
assign rvx_signal_10 = {rvx_port_12,rvx_port_14,rvx_port_56};
assign rvx_port_26 = rvx_signal_91;
assign rvx_signal_58 = rvx_port_18;

generate
for(i=0; i<RVX_GPARA_0; i=i+1)
begin : i_gen_port_i_split_r
  assign rvx_signal_26[i] = rvx_signal_52[(i+1)*RVX_LPARA_4-1-:RVX_LPARA_4];
  assign {rvx_signal_39[i],rvx_signal_07[i],rvx_port_38[i]} = rvx_signal_26[i];
  assign rvx_signal_53[i] = 0;
end
endgenerate

assign rvx_signal_65 = rvx_signal_88;

RVX_MODULE_122
#(
  .RVX_GPARA_0(RVX_GPARA_0),
  .RVX_GPARA_1(RVX_LPARA_0)
)
i_rvx_instance_1
(
  .rvx_port_2(rvx_signal_33),
  .rvx_port_6(rvx_signal_66),
  .rvx_port_4(rvx_signal_85),
  .rvx_port_0(rvx_signal_22),
  .rvx_port_3(rvx_signal_54),
  .rvx_port_5(rvx_signal_20),
  .rvx_port_1(rvx_signal_70)
);

assign rvx_signal_33 = rvx_port_55;
assign rvx_port_16 = rvx_signal_66;
assign rvx_signal_85 = {rvx_port_39};
assign rvx_port_40 = rvx_signal_54;
assign rvx_signal_20 = rvx_port_60;

generate
for(i=0; i<RVX_GPARA_0; i=i+1)
begin : i_gen_port_i_split_b
  assign rvx_signal_69[i] = rvx_signal_70[(i+1)*RVX_LPARA_0-1-:RVX_LPARA_0];
  assign rvx_signal_77[i] = rvx_signal_69[i];
  assign rvx_signal_41[i] = 0;
end
endgenerate

assign rvx_signal_22 = rvx_signal_44;

ERVP_GRANTER
#(
  .NUM_REQUEST(RVX_GPARA_0)
)
i_rvx_instance_3
(
  .clk(rvx_port_49),
  .rstnn(rvx_port_31),
  .request_hint_list(rvx_signal_29),
  .request_valid_list(rvx_signal_64),
  .request_last_list(rvx_signal_27),
  .request_ack(rvx_signal_23),
  .grant_list(rvx_signal_60),
  .granted_valid(rvx_signal_14),
  .granted_last()
);

assign rvx_signal_29 = 0;
assign rvx_signal_64 = rvx_port_37;
assign rvx_signal_27 = `ALL_ONE;
assign rvx_signal_23 = rvx_signal_11;

assign rvx_signal_11 = rvx_port_09 & rvx_port_63;
assign rvx_signal_08 = rvx_port_06 & rvx_port_61;
assign rvx_signal_48 = 0;
assign rvx_signal_79 = rvx_signal_48? 0 : rvx_signal_60;
assign rvx_signal_32 = 0;
assign rvx_signal_88 = rvx_signal_32? 0 : rvx_port_23;

ERVP_GRANTER
#(
  .NUM_REQUEST(RVX_GPARA_0)
)
i_rvx_instance_0
(
  .clk(rvx_port_49),
  .rstnn(rvx_port_31),
  .request_hint_list(rvx_signal_15),
  .request_valid_list(rvx_signal_76),
  .request_last_list(rvx_signal_81),
  .request_ack(rvx_signal_05),
  .grant_list(rvx_signal_01),
  .granted_valid(rvx_signal_46),
  .granted_last()
);

assign rvx_signal_15 = 0;
assign rvx_signal_76 = rvx_port_11;
assign rvx_signal_81 = `ALL_ONE;
assign rvx_signal_05 = rvx_signal_78;

ERVP_SINGLE_FIFO
#(
  .BW_DATA(RVX_GPARA_0)
)
i_rvx_instance_6
(
	.clk(rvx_port_49),
  .rstnn(rvx_port_31),
	.enable(rvx_port_02),
  .clear(rvx_port_29),
	.wready(rvx_signal_21),
	.wfull(rvx_signal_28),
	.wrequest(rvx_signal_19),
	.wdata(rvx_signal_75),
	.rready(rvx_signal_84),
	.rempty(rvx_signal_30),
	.rrequest(rvx_signal_35),
	.rdata(rvx_signal_55)
);

assign rvx_signal_19 = rvx_signal_78;
assign rvx_signal_75 = rvx_signal_68;
assign rvx_signal_35 = rvx_signal_51 & rvx_port_10;

assign rvx_signal_78 = rvx_port_00 & rvx_port_01;
assign rvx_signal_51 = rvx_port_62 & rvx_port_20;
assign rvx_signal_80 = rvx_port_06 & rvx_port_61;
assign rvx_signal_49 = rvx_signal_28;
assign rvx_signal_68 = rvx_signal_49? 0 : rvx_signal_01;
assign rvx_signal_57 = rvx_signal_30;
assign rvx_signal_92 = rvx_signal_57? 0 : rvx_signal_55;
assign rvx_signal_61 = 0;
assign rvx_signal_44 = rvx_signal_61? 0 : rvx_port_27;

assign rvx_port_52 = 0;

endmodule
