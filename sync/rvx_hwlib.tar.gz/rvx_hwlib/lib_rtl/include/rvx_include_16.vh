// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2025-06-18
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************


`ifndef RVX_GDEF_388
`define RVX_GDEF_388

`define RVX_GDEF_089 3
`define RVX_GDEF_042 3

`define RVX_GDEF_147 0
`define RVX_GDEF_282 4

`define RVX_GDEF_260 1
`define RVX_GDEF_161 0
`define RVX_GDEF_060 1

`define RVX_GDEF_360(SOURCE,SIZE) (`RVX_GDEF_260+`RVX_GDEF_089+SOURCE+SIZE)

`endif
