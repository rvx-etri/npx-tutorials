// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE 
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS 
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE 
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL 
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE, 
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE 
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2022-11-22
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"
`include "ervp_axi_define.vh"
`include "ervp_cache_memorymap_offset.vh"

module ERVP_ORCA_CACHE_AXI_MASTER
(
  clk,
  rstnn,

  busy,
  
  c_oimm_address,
  c_oimm_burstlength_minus1,
  c_oimm_byteenable,
  c_oimm_requestvalid,
  c_oimm_readnotwrite,
  c_oimm_writedata,
  c_oimm_writelast,
  c_oimm_readdata,
  c_oimm_readdatavalid,
  c_oimm_waitrequest,

  sxrready,
  sxrvalid,
  sxrlast,
  sxrresp,
  sxrdata,
  sxrid,
  sxarready,
  sxarvalid,
  sxarburst,
  sxarsize,
  sxarlen,
  sxaraddr,
  sxarid,
  sxbready,
  sxbvalid,
  sxbresp,
  sxbid,
  sxwready,
  sxwvalid,
  sxwlast,
  sxwstrb,
  sxwdata,
  sxwid,
  sxawready,
  sxawvalid,
  sxawburst,
  sxawsize,
  sxawlen,
  sxawaddr,
  sxawid
);

////////////////////////////
/* parameter input output */
////////////////////////////

parameter BW_ADDR = 32;
parameter BW_DATA = 32;
parameter BW_AXI_TID = 1;
parameter BW_BURST_LENGTH = 4;
parameter CACHE_LINE_SIZE = 16; // in byte

localparam NUM_BYTE_IN_DATA = `NUM_BYTE(BW_DATA);
localparam NUM_TRANSFER = `DIVIDERU(CACHE_LINE_SIZE,NUM_BYTE_IN_DATA);

input wire clk;
input wire rstnn;
output wire busy;

input wire [BW_ADDR-1:0] c_oimm_address;
input wire [BW_BURST_LENGTH-1:0] c_oimm_burstlength_minus1;
input wire [`NUM_BYTE(BW_DATA)-1:0] c_oimm_byteenable;
input wire c_oimm_requestvalid;
input wire c_oimm_readnotwrite;
input wire [BW_DATA-1:0] c_oimm_writedata;
input wire c_oimm_writelast;
output wire [BW_DATA-1:0] c_oimm_readdata;
output wire c_oimm_readdatavalid;
output wire c_oimm_waitrequest;

localparam BW_AXI_ADDR = BW_ADDR;
localparam BW_AXI_DATA = BW_DATA;

output wire sxrready;
input wire sxrvalid;
input wire sxrlast;
input wire [`BW_AXI_RRESP-1:0] sxrresp;
input wire [BW_AXI_DATA-1:0] sxrdata;
input wire [BW_AXI_TID-1:0] sxrid;
input wire sxarready;
output wire sxarvalid;
output wire [`BW_AXI_ABURST-1:0] sxarburst;
output wire [`BW_AXI_ASIZE-1:0] sxarsize;
output wire [`BW_AXI_ALEN-1:0] sxarlen;
output wire [BW_AXI_ADDR-1:0] sxaraddr;
output wire [BW_AXI_TID-1:0] sxarid;
output wire sxbready;
input wire sxbvalid;
input wire [`BW_AXI_BRESP-1:0] sxbresp;
input wire [BW_AXI_TID-1:0] sxbid;
input wire sxwready;
output wire sxwvalid;
output wire sxwlast;
output wire [`BW_AXI_WSTRB(BW_AXI_DATA)-1:0] sxwstrb;
output wire [BW_AXI_DATA-1:0] sxwdata;
output wire [BW_AXI_TID-1:0] sxwid;
input wire sxawready;
output wire sxawvalid;
output wire [`BW_AXI_ABURST-1:0] sxawburst;
output wire [`BW_AXI_ASIZE-1:0] sxawsize;
output wire [`BW_AXI_ALEN-1:0] sxawlen;
output wire [BW_AXI_ADDR-1:0] sxawaddr;
output wire [BW_AXI_TID-1:0] sxawid;

/////////////
/* signals */
/////////////

`include "lpit_function.vb"
`include "lpixm_function.vb"

localparam BW_LPIXM_ADDR = BW_ADDR;
localparam BW_LPIXM_DATA = BW_DATA;
localparam BW_LPI_BURDEN = BW_AXI2LPIXM_BURDEN(BW_AXI_TID);

`include "lpixm_lpara.vb"

wire [2-1:0] lqdready;
wire lqvalid;
wire lqhint;
wire lqlast;
wire lqafy;
wire [BW_LPI_QDATA-1:0] lqdata;

wire [2-1:0] lydready;
wire lyvalid;
wire lyhint;
wire lylast;
wire [BW_LPI_YDATA-1:0] lydata;

wire [BW_AXI_TID-1:0] xid;
wire xwrite;
wire [`BW_AXI_ALEN-1:0] xlen;
wire [`BW_AXI_ASIZE-1:0] xsize;
wire [`BW_AXI_ABURST-1:0] xburst;
wire [`NUM_BYTE(BW_AXI_DATA)-1:0] xwstrb;
wire [BW_AXI_DATA-1:0] xwdata;
wire [BW_AXI_ADDR-1:0] xaddr;

wire xwreply;
wire [`BW_AXI_RESP-1:0] xresp;
wire [BW_AXI_DATA-1:0] xrdata;

////////////
/* logics */
////////////

RVX_MODULE_119
#(
  .BW_ADDR(BW_ADDR),
  .BW_DATA(BW_DATA),
  .MEMORY_OPERATION_TYPE(3),
  .RVX_GPARA_1(BW_AXI_TID),
  .RVX_GPARA_3(NUM_TRANSFER),
  .HAS_BURDEN(1),
  .BW_BURDEN(BW_LPI_BURDEN)
)
i_lpixm2axi
(
	.rvx_port_13(clk),
	.rvx_port_05(rstnn),
  .rvx_port_27(1'b 0),
  .rvx_port_36(1'b 1),

  .rvx_port_42(lqdready),
  .rvx_port_23(lqvalid),
  .rvx_port_21(lqhint),
  .rvx_port_44(lqlast),
  .rvx_port_12(lqafy),
  .rvx_port_19(lqdata),

  .rvx_port_41(lydready),
  .rvx_port_11(lyvalid),
  .rvx_port_28(lyhint),
  .rvx_port_22(lylast),
  .rvx_port_01(lydata),

  .rvx_port_18(sxawid),
	.rvx_port_10(sxawaddr),
	.rvx_port_37(sxawlen),
	.rvx_port_20(sxawsize),
	.rvx_port_06(sxawburst),
	.rvx_port_29(sxawvalid),
	.rvx_port_09(sxawready),

	.rvx_port_33(sxwid),
	.rvx_port_16(sxwdata),
	.rvx_port_32(sxwstrb),
	.rvx_port_38(sxwlast),
	.rvx_port_24(sxwvalid),
	.rvx_port_00(sxwready), 

	.rvx_port_39(sxbid),
	.rvx_port_43(sxbresp),
	.rvx_port_25(sxbvalid),
	.rvx_port_34(sxbready),

	.rvx_port_26(sxarid),
	.rvx_port_15(sxaraddr),
	.rvx_port_30(sxarlen),
	.rvx_port_17(sxarsize),
	.rvx_port_31(sxarburst),
	.rvx_port_04(sxarvalid),
	.rvx_port_02(sxarready),

	.rvx_port_40(sxrid),
	.rvx_port_35(sxrdata),
	.rvx_port_08(sxrresp),
	.rvx_port_07(sxrlast),
	.rvx_port_03(sxrvalid),
	.rvx_port_14(sxrready)
);

assign lqvalid = c_oimm_requestvalid;
assign lqhint = 0;
assign lqlast = xwrite? c_oimm_writelast : 1;
assign lqafy = xwrite? c_oimm_writelast : 1;
assign lqdata = {xid,xwrite,xlen,xsize,xburst,xwstrb,xwdata,xaddr};

assign {xwreply, xresp, xrdata} = lydata;

assign xid = 0;
assign xwrite = ~c_oimm_readnotwrite;
assign xlen = c_oimm_burstlength_minus1;
assign xsize = `GET_AXI_SIZE(BW_AXI_DATA);
assign xburst = `AXI_BURST_INCR;
assign xwstrb = c_oimm_byteenable;
assign xwdata = c_oimm_writedata;
assign xaddr = c_oimm_address;

assign c_oimm_waitrequest = ~(lqdready[0]);
assign c_oimm_readdatavalid = lyvalid & (~xwreply);
assign c_oimm_readdata = xrdata;

assign lydready = 2'b 11;

assign busy = 0;

endmodule
