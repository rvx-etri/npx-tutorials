#ifndef __NPX_PROFILING_H__
#define __NPX_PROFILING_H__

#include "platform_info.h"
#include "ervp_profiling.h"

#define NPX_PROFILING_START PROFILING_START
#define NPX_PROFILING_END PROFILING_END

#endif
